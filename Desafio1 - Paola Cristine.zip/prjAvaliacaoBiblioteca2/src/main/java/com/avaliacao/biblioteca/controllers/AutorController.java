package com.avaliacao.biblioteca.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.avaliacao.biblioteca.entities.Autor;
import com.avaliacao.biblioteca.service.AutorService;

@RestController
@RequestMapping("/Autor")
@CrossOrigin(origins = "http://localhost:8080")
public class AutorController {
	
	private final AutorService autorService;
	
	@Autowired
	public AutorController (AutorService autorService) {
		this.autorService = autorService;
	}
	
	@PostMapping
	public Autor createProduct (@RequestBody Autor autor) {
		return autorService.saveAutor(autor);
	}
	
	@GetMapping("/{id}")
	public Autor getAutor (@PathVariable Long id) {
		return autorService.getAutorById(id);
	}
	
	@GetMapping
	public List<Autor> getAllAutor () {
		return autorService.getAllAutor();
	}
	
	@DeleteMapping("/{id}")
	public void deleteAutor (@PathVariable Long id) {
		autorService.deleteAutor(id);
	}
	
	@GetMapping("/nomeAutor/{nomeAutor}")
	public List<Autor> buscarPorNomeAutor(@PathVariable String nomeAutor){
		return autorService.buscarPorNomeAutor(nomeAutor);
	}
	
}

























