package com.avaliacao.biblioteca.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.avaliacao.biblioteca.entities.Categorias;
import com.avaliacao.biblioteca.repositories.CategoriaRepositories;


@Service
public class CategoriaService {

	private final CategoriaRepositories categoriaRepositories;
	
	@Autowired
	public CategoriaService(CategoriaRepositories categoriaRepositories) {
	this.categoriaRepositories = categoriaRepositories;
	}
	public Categorias saveCategoria (Categorias categoria) {
		return categoriaRepositories.save(categoria);
	}
	public Categorias getCategoriasById (Long id) {
		return categoriaRepositories.findById(id).orElse (null);
	}
	public List<Categorias> getAllCategoria () {
		return categoriaRepositories.findAll();
	}
	public void deleteCategorias (Long id) {
		categoriaRepositories.deleteById(id);
	}
	
	//busca por nome da categoria
	public List<Categorias> buscarPorNome(String nome){
		return categoriaRepositories.findByNome(nome);
	}
			

}































