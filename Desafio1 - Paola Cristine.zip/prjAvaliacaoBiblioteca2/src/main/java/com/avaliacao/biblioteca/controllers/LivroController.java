package com.avaliacao.biblioteca.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.avaliacao.biblioteca.entities.Livros;
import com.avaliacao.biblioteca.service.LivroService;

@RestController
@RequestMapping("/Livro")
@CrossOrigin(origins = "http://localhost:8080")
public class LivroController {

	private final LivroService livroService;
	
	@Autowired
	public LivroController (LivroService livroService) {
		this.livroService = livroService;
	}
	
	@PostMapping
	public Livros createProduct (@RequestBody Livros livros) {
		return livroService.saveLivro(livros);
	}
	
	@GetMapping("/{id}")
	public Livros getLivro (@PathVariable Long id) {
		return livroService.getLivroById(id);
	}
	
	@GetMapping
	public List<Livros> getAllLivro () {
		return livroService.getAllLivros();
	}
	
	@DeleteMapping("/{id}")
	public void deleteLivro (@PathVariable Long id) {
		livroService.deleteLivros(id);
	}
	
	@GetMapping("/titulo/{titulo}")
	public List<Livros> buscarPorTitulo(@PathVariable String titulo){
		return livroService.buscarPorTitulo(titulo);
	}
	
	

	
	
}
