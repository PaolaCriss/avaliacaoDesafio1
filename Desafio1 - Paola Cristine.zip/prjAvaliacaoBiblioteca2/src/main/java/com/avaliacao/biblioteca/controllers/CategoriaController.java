package com.avaliacao.biblioteca.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.avaliacao.biblioteca.entities.Categorias;
import com.avaliacao.biblioteca.service.CategoriaService;

@RestController
@RequestMapping("/Categoria")
@CrossOrigin(origins = "http://localhost:8080")
public class CategoriaController {
	
private final CategoriaService categoriaService;
	
	@Autowired
	public CategoriaController (CategoriaService categoriaService) {
		this.categoriaService = categoriaService;
	}
	
	@PostMapping
	public Categorias createProduct (@RequestBody Categorias categoria) {
		return categoriaService.saveCategoria(categoria);
	}
	
	@GetMapping("/{id}")
	public Categorias getCategoria (@PathVariable Long id) {
		return categoriaService.getCategoriasById(id);
	}
	
	@GetMapping
	public List<Categorias> getAllCategoria () {
		return categoriaService.getAllCategoria();
	}
	
	@DeleteMapping("/{id}")
	public void deleteCategoria (@PathVariable Long id) {
		categoriaService.deleteCategorias(id);
	}
	
	@GetMapping("/nome/{nome}")
	public List<Categorias> buscarPorNome(@PathVariable String nome){
		return categoriaService.buscarPorNome(nome);
	}
	
	
}
