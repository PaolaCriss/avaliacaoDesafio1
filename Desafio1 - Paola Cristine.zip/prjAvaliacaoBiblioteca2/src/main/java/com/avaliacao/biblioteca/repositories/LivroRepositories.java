package com.avaliacao.biblioteca.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.avaliacao.biblioteca.entities.Livros;

public interface LivroRepositories extends JpaRepository<Livros, Long> {

	@Query("SELECT l FROM Livros l WHERE l.titulo = ?1")
	List<Livros> findByTitulo(String titulo);
	

}
