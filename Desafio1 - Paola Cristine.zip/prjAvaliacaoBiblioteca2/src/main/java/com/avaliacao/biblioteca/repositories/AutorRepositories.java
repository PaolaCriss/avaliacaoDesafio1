package com.avaliacao.biblioteca.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.avaliacao.biblioteca.entities.Autor;

public interface AutorRepositories extends JpaRepository<Autor, Long> {
	
	@Query("SELECT l FROM Autor l WHERE l.nomeAutor = ?1")
	List<Autor> findByNomeAutor(String nomeAutor);
	
	
}
