package com.avaliacao.biblioteca.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.avaliacao.biblioteca.entities.Livros;
import com.avaliacao.biblioteca.repositories.LivroRepositories;

@Service
public class LivroService {

	private final LivroRepositories livroRepositories;
		
		@Autowired
		public LivroService(LivroRepositories livroRepositories) {
		this.livroRepositories = livroRepositories;
		}
		public Livros saveLivro (Livros livros) {
			return livroRepositories.save(livros);
		}
		public Livros getLivroById (Long id) {
			return livroRepositories.findById(id).orElse (null);
		}
		public List<Livros> getAllLivros () {
			return livroRepositories.findAll();
		}
		public void deleteLivros (Long id) {
			livroRepositories.deleteById(id);
		}
		
		//busca por titulo do livro
		public List<Livros> buscarPorTitulo(String titulo){
			return livroRepositories.findByTitulo(titulo);
		}
		
		
}























