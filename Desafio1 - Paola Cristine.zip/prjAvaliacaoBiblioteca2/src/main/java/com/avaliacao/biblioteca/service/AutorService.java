package com.avaliacao.biblioteca.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.avaliacao.biblioteca.entities.Autor;
import com.avaliacao.biblioteca.repositories.AutorRepositories;

@Service
public class AutorService {

	private final AutorRepositories autorRepositories;
	
	@Autowired
	public AutorService(AutorRepositories autorRepositories) {
	this.autorRepositories = autorRepositories;
	}
	public Autor saveAutor (Autor autor) {
		return autorRepositories.save(autor);
	}
	public Autor getAutorById (Long id) {
		return autorRepositories.findById(id).orElse (null);
	}
	public List<Autor> getAllAutor () {
		return autorRepositories.findAll();
	}
	public void deleteAutor (Long id) {
		autorRepositories.deleteById(id);
	}
	
	//busca por nome do autor
	public List<Autor> buscarPorNomeAutor(String nomeAutor){
		return autorRepositories.findByNomeAutor(nomeAutor);
	}
	
}
