package com.avaliacao.biblioteca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrjAvaliacaoBiblioteca2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
